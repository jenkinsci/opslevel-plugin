#! /usr/bin/python

print("We're from planet Shlorp")
