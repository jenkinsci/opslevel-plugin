A simple git repo to help test our plugin!
